
import rule from './rule'

export default {
  rule,
}
